//SU2022_MonthlySalarySlip_Dang.java
//Name: Don Dang
//ID: 3660201
//Referred back to part 1 SU2022_YourWeightManagement_Dang.java for assistance
import java.util.Scanner;public class SU2022_MonthlySalarySlip_Dang { public static void main(String[] args) {
	Scanner scnr = new Scanner(System.in);
	{ //scanner
		 int x; float y; String z; String MoneyAmount; //test variables
        String EmployeeID;		String employeeName; String PositionID;//Float/String/Int Statements
      
    //creating print statements
        SU2022_Employee_Dang SU2022_Employee_Dang;
            System.out.println("Sale Employee Name:");  //printing the statement to ask for Employee Name
            employeeName=scnr.nextLine(); //user input to store into employeeName
            
            System.out.println("Employee ID:"); //printing the statement to ask for Employee ID
            EmployeeID=scnr.nextLine(); //user input to store into EmployeeID
           
            System.out.println("Salary Range:");
            Float SalaryRange = Float.parseFloat(scnr.nextLine()); //printing the statement to ask for Salary Range
            
            System.out.println("Position ID:"); //printing the statement to ask for position ID
            PositionID=scnr.nextLine();  //user input to store into PositionID
            
            //Order from string string float string --<allows decimals
            SU2022_Employee_Dang=new SU2022_Employee_Dang(employeeName,EmployeeID,SalaryRange, PositionID); //object oriented
               System.out.println(SU2022_Employee_Dang.toString()); //output of above
               
	}
	}
}
//returns decimals!

//Allowing users to have input.