//SU2022_Employee_Dang.java
public class SU2022_Employee_Dang
{
       
	//data members
	private String EmployeeName; //String EmployeeName
	private String EmployeeID; //String EmployeeID 
	private Float SalaryRange; //Int Salary Range
	private String PositionID; //String Position ID
	private float ExtraMoney; //Float ExtraMoney
	float MonthSalary; //float MonthSalary
	float AddingTwoTogether;
	
        //no-argument constructor
	public SU2022_Employee_Dang()
	{
		EmployeeName = ""; //String
		EmployeeID = ""; //String
		SalaryRange = 0.0f; //Float
		PositionID = ""; //String
	}
	
	//parameterized constructor
	public SU2022_Employee_Dang(String n, String e, Float h, String p)
	{
		EmployeeName = n; //String
		EmployeeID= e; //String
		SalaryRange = h; //Float
		PositionID = p; //String
		
		
	}
	
	//the following are mutator methods with the names starting "set"
	public void setName(String n)
	{
		EmployeeName = n;
	}
	public void setSalaryRange(Float h) //creating void statement
	{
		SalaryRange = h;
	}
	public void setPositionID(String p)
	{
		PositionID = p;
	}
	
	//the following are  methods with the name starting "get"
	public String getEmployeeName()
	{
		return EmployeeName;
	}
	public float getSalary()
	{
		return SalaryRange;
	}
	public String getPositionID()
	{
		return PositionID;
	}
	public float getBaseMonthSalary()
	{//Salary Range if statement scenarios
		if (SalaryRange == 1) //if user inputs 1
		{
			SalaryRange = (float) 50000/12; }
			else if(SalaryRange == 2) { //if user inputs 2
				SalaryRange = (float)65306/12; }
				else if(SalaryRange == 3) //if user inputs 3
				{ SalaryRange = (float)72848/12; }
				else if(SalaryRange == 4) //if user inputs 4
				{
					SalaryRange = (float) 82000/12;
				}
		return SalaryRange;
				
				}
				
		
			
	String a = "OFF2";
	
	
	//if statements for Extra Money Scenarios
	public float calculateExtraMoney() {
		if(PositionID.equals("OFF1"))
	{
		ExtraMoney = 0;
	}
		else if(PositionID.equals("OFF2"))
	{
		ExtraMoney = (float) (.05 * SalaryRange);
	}
		else if(PositionID.equals("OFF3"))
		{
			ExtraMoney = (float) (1*SalaryRange);
		}
		else if(PositionID.equals("FF1"))
		{
			ExtraMoney = 0; }
		else if(PositionID.equals("FF2"))
			{
				ExtraMoney = (float) (.08*SalaryRange);
			}
		return ExtraMoney;
	}//method for adding the two valules of ExtraMoney and MonthSalary together.
	public float getMonthSalary()
	{
		AddingTwoTogether = getBaseMonthSalary() + calculateExtraMoney();
		return AddingTwoTogether;
	}
	//method toString to create the output string and return
	public String toString()
	{
		return 
		       "File: SU2022_MonthlySalarySlip_Dang.java\n" +
		       "------------------------------------------------\n" +
		       "Month Salary Split - Don Dang\n" + 
		       "Pay Date:  06/23/2022\n" +
		      "--------------------------------------------------\n" +
		      String.format("%-15s%25s\n", "Sale Employee Name: ", EmployeeName) +
		       String.format("%-15s%25s\n", "Employee ID: ", EmployeeID) +
		       String.format("%-15s%25.2f\n", "Salary Range: ", SalaryRange) +
		       String.format("%-15s%25s\n", "Position ID: ", PositionID) +
		       "---------------------------------------------------\n" +
		       String.format("%-15s%25s\n", "Base Month Salary: ", getBaseMonthSalary()) +
		       String.format("%-15s%25s\n", "Extra Money: ", calculateExtraMoney()) +
		       String.format("%-15s%25.2f\n", "Month Salary: ", getMonthSalary());
		      
	}
}