//SU2022_YourWeightManagement_Dang.java
//Name: Don Dang
//ID: 3660201

import java.util.Scanner;public class SU2022_YourWeightManagement_Dang {

	public static void main(String[] args) 
{
		 Scanner scnr = new Scanner(System.in);{
			 int x; float y; //test variables

                //Creating print statements and variables to store the answers in.
                
                	SU2022_Adult_Dang SU2022_Adult_Dang;
                
                	
                
                 //created variable for user's name
                 
                	System.out.println("Enter person name:"); String userName;   //printing "Enter person name"
                
                	userName=scnr.nextLine();
                //creating user height variable
                
               
                	System.out.println("Enter person height:"); int userHeight1; //printing "Enter person height"
               
                	userHeight1=scnr.nextInt();
                
                	//created bmi expected variable
                
                	System.out.println("Enter your person expected BMI:");     float userBMIexpected; //printing "Enter person expected BMI"

                userBMIexpected=scnr.nextFloat();
              //Order from string, float, float --<allows decimals
                SU2022_Adult_Dang=new SU2022_Adult_Dang(userName, userHeight1,userBMIexpected); //object oriented practice

           
                System.out.println(SU2022_Adult_Dang.toString()); //output of above


            
            
                }
    }
}