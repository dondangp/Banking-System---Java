//SU2022_Adult_Dang.java
public class SU2022_Adult_Dang
{
        //data members
	private String name;
	private int height;
	private float BMIExpected;
	
        //no-argument constructor
	public SU2022_Adult_Dang()
	{
		name = "";
		height = 0;
		BMIExpected = 0.0f;
	}
	
	//parameterized constructor
	public SU2022_Adult_Dang(String n, int h, float BMI)
	{
		name = n;
		height = h;
		BMIExpected = BMI;
	}
	
	//the following are mutator methods with the names starting "set"
	public void setName(String n)
	{
		name = n;
	}
	public void setHeight(int h) //creating void statement
	{
		height = h;
	}
	public void setBMIExpected(float BMI)
	{
		BMIExpected = BMI;
	}
	
	//the following are accessor methods with the name starting "get"
	public String getName()
	{
		return name;
	}
	public int getHeight()
	{
		return height;
	}
	public float getBMIExpected()
	{
		return BMIExpected;
	}

	//method to calculate the weight
	public float calculateWeight()
	{
		float weight = BMIExpected * (height * height) / 703;
		return weight;
	}
	
	//method toString to create the output string and return
	public String toString()
	{
		return "---------------------------------------------\n" + 
		       "File: SU2022_YourWeightManagement_Dang.java\n" +
		       "Your Weight Management - Don Dang\n" + 
		       "Standard BMI:            18.5 - 24.9\n" +
		       "---------------------------------------------\n" +
		       String.format("%-15s%25s\n", "Name: ", name) +
		       String.format("%-15s%25d\n", "Height: ", height) +
		       String.format("%-15s%25.2f\n", "BMI Expected: ", BMIExpected) +
		       "---------------------------------------------\n" +
		       String.format("%-15s%25.2f\n", "Weight: ", calculateWeight()); //<==this is the way the get weight	  
	}
}