//SU2022_Customer_Dang.java
//Name: Don Dang
//ID: 3660201
//Referred back to part 1 SU2022_SU2022_Adult_Dang.java for assistance
public class SU2022_Customer_Dang
{
    private String UserNamez;private float USERMONEY;private float interest_rate;private float SavingMoney;
   
    public SU2022_Customer_Dang()
    {
    	UserNamez = ""; USERMONEY = 0;interest_rate = 0.00f; // String , Float, Float
            
        
    }

  //parameterized constructor
    public SU2022_Customer_Dang(String username, float BIGMONEY, float interestratesz)
    {
    	UserNamez = username;USERMONEY = BIGMONEY;interest_rate = interestratesz;
       
    	//the following are mutator methods with the names starting "set"

    } public void USERNAME(String xd)
    {
    	UserNamez = xd;
    }
    public void setMoney(float m)
    {
        USERMONEY = m;
    }
    
   
    public void setinterest_rate(float xa)
    {
        interest_rate = xa;
    }
	//the following are accessor methods with the name starting "get"

    public String getName()
    {
        return UserNamez;
    }
    public void setSavingtheMoney(float BigMoney)
    {
    	SavingMoney = BigMoney;
    }
   
    
    public float settingBigMoney()
    {
        return  USERMONEY;
    }
    public float getinterest_rate()
    {
        return interest_rate;
    }
    public float IRCalculator()
    {	//method to calculate the interest rate

    float interest =  (USERMONEY * interest_rate/100);
    return interest;
    }
    
    

    public float calculateSavingMoney()
    {//method to calculate the saving amount
    float SavingAmount =  USERMONEY +  IRCalculator(); //calling in IRCalculator()
    return SavingAmount;
    }

    public String toString() 	//method toString to create the output string and return

    {
        return "---------------------------------------------\n" + 
               "File: SU2022_Customer_Dang.java\n" +
               "Saving Money Calculator Application - Don Dang\n" + 
               "---------------------------------------------\n" +
               String.format("%-15s%25s\n", "Name of customer: ", UserNamez) +
               String.format("%-15s%25.2f\n", "Amount of Money: ", USERMONEY) +
               String.format("%-15s%25.2f\n", "Interest Rate: ", interest_rate) + //accepts decimals because it is a float
               "---------------------------------------------\n" +
               String.format("%-15s%25.2f\n", "Interest Amount: ", IRCalculator()) +
        	   String.format("%-15s%25.2f\n", "Total Saved Money: ", calculateSavingMoney()); 
        	   
//accepts decimals and whole numbers, not just whole numbers
    }

	
	}




