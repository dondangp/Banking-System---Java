//SU2022_SavingMoneyCalculator_Dang.java
//Name: Don Dang
//ID: 3660201
//Referred back to part 1 SU2022_YourWeightManagement_Dang.java for assistance
import java.util.Scanner;public class SU2022_SavingMoneyCalculator_Dang { public static void main(String[] args) {
	Scanner scnr = new Scanner(System.in);{ //scanner
		 int x; float y; String z; String MoneyAmount; //test variables
        Float moneyValue;	Float interestRateCustomer;	String nameCustomer; //Float/String Statements
      
    //creating print statements
        SU2022_Customer_Dang SU2022_Customer_Dang;
            System.out.printf("Name of Customer:"); nameCustomer=scnr.nextLine(); //printing "Name of Customer:" and storing it into nameCustomer
            
            System.out.println("Amount of Money:"); moneyValue=scnr.nextFloat(); //printing "Amount of Money:" and storing it into MoneyValue.
           
            System.out.println("Interest Rate?:");interestRateCustomer=scnr.nextFloat(); //printing "Interest Rate:" and storing it into InterestRateCustomer
           
            
            //Order from string, float, float --<allows decimals
        SU2022_Customer_Dang=new SU2022_Customer_Dang(nameCustomer,moneyValue,interestRateCustomer); //object oriented
                System.out.println(SU2022_Customer_Dang.toString()); //output of above
               
	}
	}
}
//returns decimals!