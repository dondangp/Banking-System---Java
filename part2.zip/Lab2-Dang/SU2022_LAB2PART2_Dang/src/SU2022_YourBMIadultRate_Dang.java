//Don Dang
//ID: 3660201
//Part Two
import java.util.Scanner;

public class SU2022_YourBMIadultRate_Dang {
private static Scanner input;
public static void main(String[] args) {
input = new Scanner(System.in);

String User;int UserHeight;float UserWeight;float UserBMI=0; //creating variables to find BMI
//Creating user input statements

System.out.print("Enter your Name:");
User = input.nextLine();
System.out.print("Enter your Height in inches:");
UserHeight = input.nextInt();
System.out.print("Enter your Weight in pounds:");

UserWeight = input.nextFloat();
UserBMI = (UserWeight * 703) / (UserHeight * UserHeight); //calculator from the example for BMI 
//Now creating the print statements


System.out.println("----------------------------------------");
System.out.println("File: SU2022_YourBMIadultRate_Dang.java ");
System.out.println("BMI Adult Rate Calculator - Don Dang");
System.out.println("Standard BMI:            18.5 – 24.9");
System.out.println("----------------------------------------");
System.out.printf("%-20s %10s%n%-20s %10d%n%-20s %10.1f%n","Name:",User,"Height (inches):",UserHeight,"Weight (lbs):",UserWeight);
System.out.println("----------------------------------------");
System.out.printf("%-20s %10.1f%n","BMI:",UserBMI);}
}
//for some reason the answer keeps rounding up, I am not too sure on how to make it two digit decimals :()