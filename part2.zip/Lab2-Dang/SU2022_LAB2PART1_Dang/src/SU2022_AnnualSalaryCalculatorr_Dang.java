//Don Dang
//ID: 3660201
import java.util.Scanner;
public class SU2022_AnnualSalaryCalculatorr_Dang { 
private static Scanner input;
public static void main(String[] args) 

{
int amountHours; //creating an int for amount of hours worked
double hourlyRate; //creating hourly rate
String employeeName; //string for the employee's name
input = new Scanner(System.in);
System.out.print("Enter Name of Employee:"); //print statement for user to input employee name
employeeName=input.nextLine();
System.out.print("Enter Hourly salary:"); //input for hourly rate for user
hourlyRate = input.nextDouble();
System.out.print("Number of working hours in each week:"); //input for user to put how much hours worked in the week
amountHours = input.nextInt();

double salary=hourlyRate * amountHours * 52; //calculates the salary by multiplying the hourly rate by amount of hours

System.out.println("---------------------------------------------------");
System.out.println("File: SU2022_AnnualSalaryCalculator_Dang.java");
System.out.println("Annual Salary Application -  Don Dang");
System.out.println("---------------------------------------------------");
System.out.printf("%-40s %10s%n%-40s %10.1f%n%-40s %10d%n", "Name of Employee:", employeeName, "Hourly salary:", hourlyRate, "Number of working hours in each week:", amountHours);
System.out.println("---------------------------------------------------");
System.out.printf("%-40s %10.1f%n","Yearly salary is:", salary); } } 
//Unsure on how to make it two decimal places I am really sorry for failing you :(.