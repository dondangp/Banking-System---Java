public class SU2022_OutputOnScreen_Dang { //Changed name of White to Dang --used inclass example 
   public static void main(String[] args) { //12 line print statements
       System.out.println("-----------------------------------------------------------");
       System.out.println("File OutputOnScreen_Dang.java");
       System.out.println("Welcome to Java class – Programming Fundamental II");
       System.out.println("Summer 2022 Semester - short term");
       System.out.println("-----------------------------------------------------------");
       System.out.println("My name is: Don Dang");
       System.out.println("This is my first Java Program");
       System.out.println("The lab should be turned in on time to get max score");
       System.out.println("Each lab has only 1 week for late");
       System.out.println("Late lab will be lost 3 points");
       System.out.println("Contact to your instructor to get help. Enjoy programming!");
       System.out.println("-----------------------------------------------------------"); } }
//3-14 12 output