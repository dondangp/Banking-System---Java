import java.util.Scanner; // to import scanner class

public class SU2022_PracticeWithVariables_Dang{ //Changed White to my last name (Dang)

   public static void main(String[] args) {
       try (
    Scanner sc = new Scanner(System.in)) { //This would be utilized to prompt for required strings (3) needed for the code
        //Using User input
           System.out.print("Enter word 1: ");
           String word1=sc.next(); //Using user input
           System.out.print("Enter word 2: ");
           String word2=sc.next();
           System.out.print("Enter word 3: ");
           String word3=sc.next();
           sc.nextLine(); // Next code would be uitilized for the decimals. Practiced using doubles!
           System.out.print("Enter the first number:");
           double deca1=sc.nextDouble();
           System.out.print("Enter the Second number: ");
           double decb2=sc.nextDouble(); //Now this would be the output of the code
           System.out.println("\n------------------------------------------------------"); 
           System.out.println("File: PracticeWithVariables_Dang.java");
           System.out.println("Summer 2022 semester - Don Dang");
           System.out.println("------------------------------------------------------");
           System.out.println("Word 1: "+word1);
           System.out.println("Word 2: "+word2);
           System.out.println("Word 3: "+word3);
           System.out.println("First number: "+deca1); //Calling the user to input the first number.
           System.out.println("Second number: "+decb2); //Calling the user to input the second number.
           System.out.println("Average of "+deca1+" and "+decb2+" is: "+(deca1+decb2)/2); } //The calculator of the two values combined
       System.out.println("------------------------------------------------------");
   }

} //11 output lines