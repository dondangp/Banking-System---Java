//SU2022_MortgageAccount_Dang.java
import java.util.Random;


public class SU2022_MortgageAccount_Dang
{
       
	//data members
	private int accountNumber; //int accountNumber
	private String lastname; //String last name 
	private String firstname; //string first name
	private float principal; //String Principal
	private int payments; //int payments
	float interestrate; //float interestrate
	float monthlypayment; 
	int number;
	float amountpaid;
	float interestamountthismonth;
	Random generator = new Random(); //random number generator
        //no-argument constructor
	public SU2022_MortgageAccount_Dang()
	{	

	for ( accountNumber=0; accountNumber<=10; accountNumber++ )
	{
		number = generator.nextInt(10);
	}}
	 public float getMonthlyPayment() //calculate monthly payment
     {
  	   return monthlypayment;
     }
	//parameterized constructor
	public SU2022_MortgageAccount_Dang(int n, String e, String h, Float p,  int a, float b , float c , float d, float f)
	{
		accountNumber = n; //int
		lastname= e; //String
		firstname = h; //string
		principal = p; //float
		payments = a; //int
		interestrate = b; //float
		monthlypayment = c; //float
		amountpaid = d; // float
		interestamountthismonth = f; //float
		
	}
	public float getInterestAmount() {
		interestrate = principal*interestrate/100/12;
		return interestrate;
	}
	
	public int payments() {
		payments = payments - 1;
		return payments;
	}
	public float getnewPrincipalAmount() {
		principal = principal-(amountpaid-getInterestAmount());
		return principal;
	}
	//the following are mutator methods with the names starting "set"
	public void setAccountNumber(int n)
	{
		accountNumber = n;
	}
	public void setInterestAmountMonth(Float d) //creating void statement
	{
		interestamountthismonth = d;
	}
	public void setprincipal(float p)
	{
		principal = p;
	}
	public void firstname(String h)
	{
		firstname = h;
	}
	public void setprincipal(String e)
	{
		lastname = e;
	}
	
	public void setpayments(int a)
	{
		payments = a;
	}
	
	
	//the following are  methods with the name starting "get"
	
	

	
	
	//method toString to create the output string and return
	public String toString()
	{
		return 
		       "File: SU2022_MortgageAccount_Dang.java\n" +
				"OPEN NEW ACCOUNT: DON DANG\n"+
		       "------------------------------------------------\n" +
		       String.format("%-15s%25s\n", "Account Number: ", accountNumber) +
		       "Name:  Don, Dang\n" +
		      String.format("%-15s%25s\n", "Principal: ", principal) +
		       String.format("%-15s%25s\n", "Number of payments:", payments) +
		       String.format("%-15s%25.3f\n", "Interest rate: ", interestrate) +
		       String.format("%-15s%25s\n", "Monthly payment: ", monthlypayment) +
		       String.format("%-15s%25s\n", "Amount you pay: ", amountpaid) +
		       String.format("%-15s%25s\n", "Interest amount this month:", getInterestAmount()) +
		       "------------------------------------------------\n" +
		       String.format("%-15s%25.2f\n", "Principal: ", getnewPrincipalAmount());
		      
	}
}