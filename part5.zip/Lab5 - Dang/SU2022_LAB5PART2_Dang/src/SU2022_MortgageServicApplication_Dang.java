//SU2022_MortgageServicApplication_Dang.java
//Name: Don Dang
//ID: 3660201
//Referred back to part 1 SU2022_YourWeightManagement_Dang.java for assistance
import java.util.Scanner;public class SU2022_MortgageServicApplication_Dang { public static void main(String[] args) {
	Scanner scnr = new Scanner(System.in); String Choose;
	{ //scanner  creating variables
		 int x; float y; String z; String MoneyAmount; //test variables
        String EmployeeID;		String employeeName; String PositionID;//Float/String/Int Statements
        int accountNumber; //int
       String lastname; //String
       String firstname; //string
      float principal; //float
        int payments; //int
      float  interestrate; //float
      float  monthlypayment; //float
      float amountyoupay; //float
      float  interestamountthismonth; //float
      
    //creating print statements
        SU2022_MortgageAccount_Dang SU2022_MortgageAccount_Dang;
            System.out.print("1.Calculate the Mortgage Monthly Payment\n2.Open Account for Mortgage Service\n3.Check Interest Rate of current Mortgage Account\n4.Check Current Principal of current Mortgage Account\n5.Monthly Payment Process\n0.Exit: \n");  //printing the statement to ask for Employee Name
            employeeName=scnr.nextLine(); 
            if(employeeName.equals("1"))
            {
            	
            }
            //user input for questions
			System.out.printf("Account number:");
            accountNumber=scnr.nextInt(); 
           
            System.out.println("Last name: ");
            lastname=scnr.nextLine(); 
            System.out.println("First name: ");
            firstname=scnr.nextLine(); 
            System.out.printf("Principal:");
            principal=scnr.nextFloat(); 
            System.out.println("Number of payments: "); 
            payments=scnr.nextInt();  
            System.out.println("Interest Rate: "); 
            interestrate=scnr.nextFloat();  
            
            System.out.println("Monthly Payment: "); 
            monthlypayment=scnr.nextFloat();  
            System.out.println("Amount you pay: "); 
            amountyoupay=scnr.nextFloat();  
            System.out.println("Interest amount this month: "); 
            interestamountthismonth=scnr.nextFloat();  //user input to store into PositionID
            
            //follow constructor from SU2022_MortgageAccount_dang.java
            SU2022_MortgageAccount_Dang=new SU2022_MortgageAccount_Dang(accountNumber,lastname,firstname,principal, payments, interestrate, monthlypayment, amountyoupay,interestamountthismonth); //object oriented
               System.out.println(SU2022_MortgageAccount_Dang.toString()); //output of above
               
              
	}
	}
}
//returns decimals!

//Allowing users to have input.