//SU2022_EvaluateHomework_Dang.java
//Name: Don Dang
//ID: 3660201
//Referred back to part 1 SU2022_YourWeightManagement_Dang.java for assistance
import java.util.Scanner;public class SU2022_EvaluateHomework_Dang { public static void main(String[] args) {
	Scanner scnr = new Scanner(System.in);
	{ //scanner
		 int x; float y; String z; String MoneyAmount; //test variables
        String studentID;		String studentFirstName = null;  String studentLastName = null; String PositionID;//Float/String/Int Statements
        char[] answers = new char[20];
        String studentFullName = studentFirstName + studentLastName;
    //creating print statements
        SU2022_StudentDoHomework_Dang SU2022_StudentDoHomework_Dang;
        
        System.out.println("Student's name:");  //printing the statement to ask for Student Name
            studentFullName=scnr.nextLine(); //user input to store into studentFullName
            
            System.out.println("Student's ID:"); //printing the statement to ask for Student ID
            studentID=scnr.nextLine(); //user input to store into EmployeeID
           
            
            
            //Order from string string float string --<allows decimals
            SU2022_StudentDoHomework_Dang=new SU2022_StudentDoHomework_Dang(studentFullName,studentID,  answers); //object oriented
               System.out.println(SU2022_StudentDoHomework_Dang.toString()); //output of above
               
	}
	}
}
//returns decimals!

//Allowing users to have input.