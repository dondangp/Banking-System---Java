//SU2022_StudentDoHomework_Dang.java
public class SU2022_StudentDoHomework_Dang 
{
	

        //data members
	private String name;
	private String firstName;
	private String lastName;
	private String studentID;
	private char[] answers = new char[20];
	
	
        //no-argument constructor
	public SU2022_StudentDoHomework_Dang()
	{
		
		name = "";
		studentID = "";
		this.answers[20] = answers[20];
	}
	
	//parameterized constructor
	public SU2022_StudentDoHomework_Dang(String c, String h,  char[] a)
	{
		
		name = c;
		studentID = h;
		answers = a;
	}
	
	//the following are mutator methods with the names starting "set"
	public void setName(String n)
	{
		name = n;
	}
	
	public void setBMIExpected(char[] a)
	{
		answers = a;
	}
	

	
	//printResult() method
	public int[] printResult()
	{
		String wrongQuestions = null;
		float score=0;
		int result[] = new int [20];
		char[] key = new char [20];
		char[] answers = new char[20];
		if(key[0] == answers[0] || key[0]== '0' && answers[0] == '0')
		{
			result[0] =1;
		}
		
		for(int i=0;i<20;i++)
		{
			
			result[i]=(int) (i+1);
			
			
			
		}
		
		
		return result;
	
		
	}
	public int calculateWrongquestions()
	{
		return 0;
	}
	
	

	
	public String toString()
	{
		return "---------------------------------------------\n" + 
		       "File: SU2022_EvaluateHomework_Dang.java\n" +
		       "STUDENT HOMEWORK RESULT - Don Dang\n" + 
		       "---------------------------------------------\n" +
		       String.format("%-15s%25s\n", "Student's name: ", name) +
		       String.format("%-15s%25s\n", "Student's ID ", studentID) +
		       "Homework date:                     06/27/2022\n"+
		       "---------------------------------------------\n"  +
		      
		       "Homework: 20 questions - Max score = 10 points\n" +
		       String.format("%-15s%25s\n", "Homework score:", printResult()) +
		       String.format("%-15s%25s\n", "Wrong questions:" , calculateWrongquestions());
		 	
		       
		        
	
}
}